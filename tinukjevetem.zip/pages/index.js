export default function Home() {
  return (
    <div style={styles.container}>
      <img src="/logo.png" alt="Logo" style={styles.logo} />
      <h1 style={styles.title}>Ti Nuk Je Vetëm</h1>
      <p style={styles.text}>
        Ky është vendi yt i sigurt. Një hapësirë e ngrohtë ku askush nuk të gjykon dhe ku çdo shpirt ndjen se nuk është vetëm.
      </p>
      <div style={styles.box}>
        <h2>Mesazh motivues:</h2>
        <p>
          Ndonjëherë rruga duket e gjatë, por çdo hap që bën përpara është një fitore. Mos harro: prindërit e tu kanë sakrifikuar shumë për ty. Bëji krenarë. Bëje veten krenar.
        </p>
      </div>
      <footer style={styles.footer}>
        Krijuar me dashuri nga Klajdi & ChatGPT
      </footer>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    padding: '2rem',
    backgroundColor: '#fff0f5',
    fontFamily: 'sans-serif',
    textAlign: 'center',
  },
  logo: {
    width: '120px',
    marginBottom: '1rem',
  },
  title: {
    fontSize: '2.5rem',
    color: '#a83279',
  },
  text: {
    fontSize: '1.2rem',
    marginTop: '1rem',
    color: '#444',
  },
  box: {
    marginTop: '2rem',
    padding: '1.5rem',
    backgroundColor: '#ffe6f0',
    borderRadius: '12px',
    color: '#6a1b4d',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
  },
  footer: {
    marginTop: '3rem',
    fontSize: '0.9rem',
    color: '#888',
  },
};